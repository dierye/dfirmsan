from qiling import Qiling
from qiling.os.posix import syscall
from qiling.const import QL_INTERCEPT, QL_VERBOSE
from qiling.os.const import UINT, POINTER, STRING, INT
from qiling.os.mapper import QlFsMappedObject 
from qiling.extensions.afl import ql_afl_fuzz
from qiling.os.posix.structs import *
from qiling.extensions.sanitizers.heap import QlSanitizedMemoryHeap
import os, sys, socket, random
from pwn import *


def nvram_read(ql: Qiling, fd: int, buf: int, count: int) -> int:
    try:
        data = ql.mem.read(buf, count)
        fobj = ql.os.fd[fd]
        ql.log.info(f'hook read "{fobj.name}"')
        ret = 0
        if "/dev/nvram" in fobj.name:
            ql.log.info(f'nvram operation')
            file = open(f'{rootfs}/dev/nvram','r')
            content = file.read(0x1000)
            str_data = data.decode('utf-8')[:count-1]
            pos = content.find(str_data) + count
            array = content.split('\n')
            #ql.log.info(f'{array}')
            i = 0
            while(i < len(array)):
                #ql.log.info(f'"{str_data}"+"{array[i][:count-1]}"')
                if str_data == array[i][:count-1]:
                    read_data = array[i].split('=')[1]
                    #ql.log.info(f'{read_data}')
                    ql.mem.write(buf, p32(pos))
                    ret = 4
                    break
                i = i + 1
        elif "/dev" in fobj.name:
            ql.log.info(f'{fobj.name} operation')
            ql.log.info(f'{fobj.tell()}')
            #ql.log.info(f'{fobj.index()}')
            if fobj.tell() > 1000:
                fobj.seek(0)
            content = bytes(fobj.read(count))
            ql.log.info(f'{content}')
            ql.mem.write(buf, content)
            ret = len(content)
        else:
            content = bytes(fobj.read(count))
            ql.mem.write(buf, content)
            ret = len(content)
    except:
        try:
            content = bytes(fobj.read(count)) 
            ql.log.info(f'{content}')
            ql.mem.write(buf, content)
            ret = len(content)
        except:
            ret = -1
    return ret

def new_malloc(ql):
    global nvram_buf
    if getattr(ql.arch, 'type', False) == 106:
        nvram_buf = ql.arch.regs.v0
    elif getattr(ql.arch, 'type', False) == 103 or getattr(ql.arch, 'type', False) == 105:
        nvram_buf = ql.arch.regs.r0
    #ql.log.info(f'nvram_buf: {nvram_buf}')


def new_ioctl(ql: Qiling, fd: int, cmd: int, buf: int) -> int:
    global open_nvram
    #ql.log.info(f'{open_nvram}')
    #ql.log.info(f'{cmd}')
    if open_nvram == 1:
        open_nvram = 0
        if cmd == 1:
            ql.os.set_syscall('close', new_close, QL_INTERCEPT.EXIT)
    return 0

def nvram_bufget_new(ql):
    params = ql.os.resolve_fcall_params({'num': INT, 'bufget_str': STRING})
    global bufget_str
    bufget_str = params['bufget_str']
    pass

def close_close(ql: Qiling, fd: int, unknown: int) -> int:
    pass

def new_close(ql: Qiling, fd: int, unknown: int) -> int:
    file = open(f'{rootfs}/dev/nvram', 'r')
    content = file.read(0x1000)
    global bufget_str
    data = bufget_str
    #ql.log.info(f'data: {data}')
    count = len(data)
    str_data = data[:count-1]
    array = content.split('\n')
        #ql.log.info(f'{array}')
    i = 0
    while(i < len(array)):
            #ql.log.info(f'"{str_data}"+"{array[i][:count-1]}"')
        if str_data == array[i][:count-1]:
            read_data = array[i].split('=')[1]
            #ql.log.info(f'{read_data}')
            global nvram_buf
            ql.mem.write(nvram_buf, bytes(read_data, encoding="utf-8"))
            break
        i = i + 1
    ql.os.set_syscall('close', close_close, QL_INTERCEPT.EXIT)
    #ql._exit()



def nvram_write(ql: Qiling, fd: int, buf: int, count: int) -> int:
    try:
        data = ql.mem.read(buf, count)
        fobj = ql.os.fd[fd]
        ql.log.info(f'hook write "{fobj.name}"')
        if "/dev/nvram" in fobj.name:
            ql.log.info(f'nvram operation')
            content = fobj.read(0x1000)
            key = data.split(b'=')[0]
            if content.find(key) == -1:
                fobj.write(data+b'\n')
        else:
            fobj.write(data)
    except:
        try:
            fobj.write(data)
            ret = len(data)
        except:
            ret = -1
    else:
        ret = count
    return ret

def pre_setsockopt(ql: Qiling):
    params = ql.os.resolve_fcall_params({'fd': INT, 'level': INT, 'optname': INT, 'optval': INT, 'length': INT})
    fd = params['fd']
    level = params['level']
    optname = params['optname']
    optval = params['optval']
    length = params['length']
    i = 0
    while length > 0:
        ip_addr = ql.mem.read(optval+i, 4)
        ip_addr = str(hex(int(str(ip_addr[0]),16)))[2:]+'.'+str(hex(int(str(ip_addr[1]),16)))[2:]+'.'+str(hex(int(str(ip_addr[2]),16)))[2:]+'.'+str(hex(int(str(ip_addr[3]),16)))[2:]
        ql.log.info(f"ip_addr: {ip_addr}")
        if ip_addr != "172.17.0.2" and ip_addr != "1.0.0.0":
            os.system(f'tunctl -t tap0 -u root')
            os.system(f'ifconfig tap0 {ip_addr}')
        length = length - 4
        i = i + 4
    return fd, level, optname, optval, length
    #pass

def fake_nvram_get(ql):
    params = ql.os.resolve_fcall_params({'s': STRING})
    s = params['s']
    ql.log.info(f'set "{s}"')

def fake_daemon(ql):
    return 0

def fake_bd_read_sn(ql):
    return 0

def dev_open(ql: Qiling, filename: int, oflag: int, mode: int) -> int:
    params = ql.os.resolve_fcall_params({'file_name': STRING})
    file_name = params['file_name']
    ql.log.info(f'file_name: {file_name}')
    if '/dev/nvram' in file_name:
        global open_nvram
        open_nvram = 1
    if os.path.exists(file_name) != True:
        path = file_name.rpartition('/')[0]
        os.system(f'mkdir -p {path}')
        os.system(f'touch {file_name}')
        if '/dev' in file_name:
            dev_list.append(file_name)
    pass


def pre_socket(ql):
    global socket_content_parsed
    params = ql.os.resolve_fcall_params({'domain': INT, 'type': INT, 'protocol': INT})
    domain = params['domain']
    ql.log.info(f'domain: {domain}')
    type_ = params['type']
    protocol = params['protocol']
    if domain == 2 or domain == 3:
        ql.log.info(f'socket content parsed: {socket_content_parsed}')
        if socket_content_parsed == 0:
            ql.log.info('process input seed')
            filein = open('./test','rb')
            testin = filein.read()
            filein.close()
            #ql.log.info(testin)
            process_input_seed(ql, testin, ql.os.exit_point)
            #ql_afl_fuzz(ql, input_file=input_file, place_input_callback=process_input_seed, exits=[ql.os.exit_point])
    pass

def aft_socket(ql):
    if getattr(ql.arch, 'type', False) == 106:
        fd = ql.arch.regs.v0
    elif getattr(ql.arch, 'type', False) == 103 or getattr(ql.arch, 'type', False) == 105:
        fd = ql.arch.regs.r0
    ql.log.info(f'fd: {fd}')
    global current_fd
    current_fd = fd
    hooked_fd.append(fd)
    #params = ql.os.resolve_fcall_params({'domain': INT, 'type': INT, 'protocol': INT})
    #domain = params['domain']
    #type_ = params['type']
    #protocol = params['protocol']
    #ql.log.info(f'domain: {domain}')
    #if domain == 2 or domain == 3:
    #    if socket_content_parsed == 0:
    #        process_input_seed()
    return fd

class sock_packets:
    def __init__(self):
        self.num = [0 for i in range(8)]
        self.packets = [['' for i in range(10)] for j in range(6)]
        self.length = [[0 for i in range(10)] for j in range(6)]


def process_input_seed(ql: Qiling, input: bytes, _):
    global socket_content_parsed
    if socket_content_parsed == 1:
        ql.log.info('socket content has parsed')
        return 0
    else:
        #global input_file
        #ql_afl_fuzz(_ql, input_file=input_file, place_input_callback=place_input_callback, exits=[ql.os.exit_point])
        ql.log.info('process input seed')
        buf = input
        global fuzz_input
        fuzz_input = input
        buf = b'\x01\x00\x00\x06\xff' + buf
        read_num = len(buf)
        if read_num <= 5:
            ql.log.info("Error, to small seed")
            ql._exit(0)
        global all_sock_contents# = sock_packets()
        global accept_num
        global current_fd
        accept_num = buf[0] % 4
        connect_num = buf[1] % 4
        total = accept_num + connect_num
        ql.log.info(f'accept_num: {accept_num}; connect_num: {connect_num}')
        if accept_num == 0:
            ql._exit(0)
        has_packet = 0
        smallest_sock_index = -1
        pointer = 2
        global shutdown_flag
        while(pointer < read_num and pointer+2 < read_num and shutdown_flag == 0):
            pointer += 1
            sock_index = buf[pointer]
            #ql.log.info(f'sock_index: {sock_index}')
            if sock_index >= total and total > 0:
                sock_index = sock_index % total
            if sock_index >= 6:
                break
            if all_sock_contents.num[sock_index] >= 10:
                ql.log.info('content greater than threshold')
                break
            ql.log.info(f'sock_index: {sock_index}')
            length = len(buf)#buf[pointer] + (int(buf[pointer+1]) << 8)
            pointer += 2
            if length > read_num - pointer:
                length = read_num - pointer
            if length < 0:
                break
            content = buf[pointer:pointer+length]
            pointer += length
            pkt_index = all_sock_contents.num[sock_index]
            all_sock_contents.num[sock_index] += 1
            all_sock_contents.length[sock_index][pkt_index] = length
            all_sock_contents.packets[sock_index][pkt_index] = buf
            ql.log.info(f'all sock contents: {content}')
            has_packet = 1
            if (sock_index > smallest_sock_index):
                smallest_sock_index = sock_index
            socket_content_parsed = 1
        if (has_packet == 0):
            ql.log.info('no non-zero length packet got')
            ql._exit(0)
        if (smallest_sock_index >= accept_num):
            ql.log.info('no packets for accept sock')
            ql._exit(0)


class sockaddr_un:
    def __init__(self):
        self.sun_family = socket.AF_UNIX
        self.sun_path = ''

class client_para:
    def __init__(self):
        self.servfd = 0
        self.self_index = 0

    def connect_write(self):
        ql.log.info(f'connect write for serverfd={self.servfd}')
        sockfd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #serun = sockaddr_un()
        #serun.sun_path = '0'+'unix.socket.'+str(self.servfd)+str(rand.rand())
        #length = 
        global ip
        global fd_port
        for i in range(len(fd_port)):
            if self.servfd in fd_port[i]:
                port = int(fd_port[i].get(self.servfd))
        ql.log.info(f'ip: {ip} port: {port} fd_port: {fd_port}')
        if port <= 1024:
            port += 8000
        sockfd.connect((ip, port))
        if (all_sock_contents.num[self.self_index] == 0):
            sockfd.close()
        for i in range(0,all_sock_contents.num[self.self_index]):
            if shutdown_flag == 1:
                break
            if all_sock_contents.length[self.self_index][i] > 65536:
                readsize = 65536
            else:
                readsize = all_sock_contents.length[self.self_index][i]
            buf = all_sock_contents.packets[self.self_index][i][5:readsize+5]
            ql.log.info(f'buf: {buf}')
            total_n = readsize
            n = 0
            r = 0
            while(n != total_n and shutdown_flag==0):
                global fuzz_input
                r = sockfd.send(buf)
                #fuzz_input = buf
                #r = os.write(self.servfd, buf)
                if r < 0:
                    ql.log.info('send error')
                    #sockfd.close()
                ql.log.info(f'num: {r}')
                n += r

def pre_listen(ql):
    params = ql.os.resolve_fcall_params({'sockfd': INT, 'backlog': INT})
    global listen_sockfd
    listen_sockfd = params['sockfd']

def aft_listen(ql):
    params = ql.os.resolve_fcall_params({'sockfd': INT, 'backlog': INT})
    #sockfd = params['sockfd']
    global listen_sockfd
    global accept_done_num
    global all_sock_contents
    ql.log.info(f'fd: {listen_sockfd}')
    backlog = params['backlog']
    ql.log.info('listen')
    if hooked_fd.count(listen_sockfd) > 0:
        ql.log.info(f'hooked fd: {hooked_fd}')
        ql.log.info(f'accept num: {accept_num}')
        while(1):
            if (accept_done_num < accept_num):
                ql.log.info(f'loop')
                global next_alloc_index
                selected_fd_index = listen_sockfd % 6
                ql.log.info(f'selected fd: {listen_sockfd}')
                next_alloc_index += 1
                accept_done_num += 1
            else:
                break
            if (all_sock_contents.num[selected_fd_index]==0):
                #ql.log.info(f'sock index {selected_fd_index} no packet')
                para = client_para()
                para.self_index = selected_fd_index
                para.servfd = listen_sockfd
                ql.log.info('connect write')
                para.connect_write()
            else:
                para = client_para()
                para.self_index = selected_fd_index
                para.servfd = listen_sockfd
                ql.log.info('connect write')
                para.connect_write()
                

#def fake_inet_addr(ql):
#    params = ql.os.resolve_fcall_params({'ip': STRING, 'sta': INT})
#    ip = params['ip']
#    ql.log.info(f'ip {ip}')
#    ql.os.exit()


def aft_accept(ql):
    if getattr(ql.arch, 'type', False) == 106:
        new_fd = ql.arch.regs.v0
    elif getattr(ql.arch, 'type', False) == 103 or getattr(ql.arch, 'type', False) == 105:
        new_fd = ql.arch.regs.r0
    params = ql.os.resolve_fcall_params({'sockfd': INT, 'addr': INT, 'len': INT})
    sockfd = params['sockfd']
    addr = params['addr']
    length = params['len']
    if hooked_fd.count(sockfd) > 0:
        is_server.append(sockfd)
        if new_fd > 0:
            hooked_fd.append(new_fd)

def ntohs(ql, nval):
    ebdata = nval.to_bytes(length=2, byteorder='big')
    return ql.unpack16(ebdata)

def pre_bind(ql):
    params = ql.os.resolve_fcall_params({'sockfd': INT, 'addr': INT, 'len': INT})
    sockfd = params['sockfd']
    addr = params['addr']
    length = params['len']
    ql.log.info(f'sockfd: {sockfd}')
    port = ql.mem.read(addr, length)
    port_ = ''
    abits = ql.arch.bits
    endian = ql.arch.endian
    sockaddr = make_sockaddr_in(abits, endian)
    sockaddr_obj = sockaddr.from_buffer(port)
    port_ = ntohs(ql, sockaddr_obj.sin_port)
    ql.log.info(f'port: {port_}')
    global fd_port
    fd_port.append({sockfd: port_})
    
def aft_recv(ql):
    global flag
    flag = 0

def aft_recvfrom(ql):
    global flag
    flag = 0

def new_select(ql):
    ql.log.info(f'exit')
    global flag
    global e
    ql.arch.regs.pc = e.plt['exit']#0xbc64
    ql.arch.regs.ra = e.plt['exit']

def end(ql):
    ql.log.info(f'end')
    ql.os.set_api('select', new_select)

def new_apmib_init(ql):
    return 1 

def new_apmib_get(ql):
    params = ql.os.resolve_fcall_params({'num': INT, 'addr': INT})
    ql.log.info(f"{hex(params['num'])}")
    ql.log.info(f"{hex(params['addr'])}")
    if params['num'] == 0x256:
        ql.mem.write(params['addr'], b'\xf1')
    elif params['num'] == 170:
        ql.mem.write(params['addr'], b'\x01\x00\x00\x7f')
    elif params['num'] == 0x2c1:
        ql.mem.write(params['addr'], b'1')
    elif params['num'] == 1474:
        ql.mem.write(params['addr'], b'eth0')
    return 0

def hook_v0(ql):
    ql.arch.regs.v0 = 1

def pre_sscanf(ql):
    params = ql.os.resolve_fcall_params({'addr': INT, 'flag': CHAR, 'tar_address': INT})
    ql.log.info(f"{params['addr']}")

def pre_getsockopt(ql):
    params = ql.os.resolve_fcall_params({'sockfd': INT, 'level': INT, 'optname': INT, 'optval_addr': INT, 'optlen_addr': INT})
    #ql.log.info(f"{params['optname']}")
    #ql.log.info(f"{params['optval_addr']}")
    #ql.log.info(f"{ql.mem.read(params['optval_addr'], 16)}")
    if params['optname'] == 80:
        ql.log.info(f"hook opt")
        params['optname'] = 0x1001
        return params 
    else:
        pass

if __name__ == "__main__":
    arg = sys.argv[1]
    root = sys.argv[2]
    input_file = sys.argv[3]
    argv = f'{arg}'.split('+')
    elf = arg.split('+')[0]
    e = ELF(elf)
    rootfs = f'{root}'
    dev_list = []
    hooked_fd = []
    is_server = []
    flag = 0
    pre_flag = 0
    ip = b'127.0.0.1'
    fd_port = []
    fuzz_input = b''
    current_fd = 0
    listen_sockfd = 0
    accept_sock_num = 0
    accept_done_num = 0
    open_nvram = 0
    nvram_buf = 0
    accept_num = 0
    next_alloc_index = 0
    socket_content_parsed = 0
    all_sock_contents = sock_packets()
    shutdown_flag = 0
    ql = Qiling(argv, rootfs)#, verbose=QL_VERBOSE.DEBUG)
    ### device
    ql.os.set_syscall('read', nvram_read, QL_INTERCEPT.CALL)
    ql.os.set_syscall('write', nvram_write, QL_INTERCEPT.CALL)
    ql.os.set_syscall('open', dev_open, QL_INTERCEPT.ENTER)
    #ql.os.set_syscall('memcmp', new_memcmp, QL_INTERCEPT.CALL)
    ql.os.set_syscall('ioctl', new_ioctl, QL_INTERCEPT.CALL)
    #ql.os.set_syscall('sscanf', pre_sscanf, QL_INTERCEPT.ENTER)
    ql.os.set_api('nvram_bufget', nvram_bufget_new, QL_INTERCEPT.ENTER)
    ql.os.set_api('malloc', new_malloc, QL_INTERCEPT.EXIT)
    #ql.hook_address(hook_v0, 0x41860c)
    #ql.hook_address(hook_v0, 0x40fdc4)
    #ql.os.set_api('apmib_init', new_apmib_init)
    ql.os.set_api('apmib_get', new_apmib_get)
    ql.os.set_api('apmib_update', new_apmib_get)
    ### network->stdin/out
    ql.os.set_api('socket', pre_socket, QL_INTERCEPT.ENTER)
    ql.os.set_api('socket', aft_socket, QL_INTERCEPT.EXIT)
    ql.os.set_api('listen', pre_listen, QL_INTERCEPT.ENTER)
    ql.os.set_api('listen', aft_listen, QL_INTERCEPT.EXIT)
    ql.os.set_api('setsockopt', pre_setsockopt, QL_INTERCEPT.ENTER)
    ql.os.set_api('accept', aft_accept, QL_INTERCEPT.EXIT)
    ql.os.set_api('accept4', aft_accept, QL_INTERCEPT.EXIT)
    ql.os.set_api('bind', pre_bind, QL_INTERCEPT.ENTER)
    ql.os.set_api('recvfrom', aft_recvfrom, QL_INTERCEPT.EXIT)
    ql.os.set_api('recv', aft_recv, QL_INTERCEPT.EXIT)
    #ql.os.set_api('getsockopt', pre_getsockopt, QL_INTERCEPT.ENTER)
    ### exit
    ql.os.set_api('send', end, QL_INTERCEPT.ENTER)
    ql.os.set_api('req_flush', end, QL_INTERCEPT.ENTER)
    #ql.os.set_api('sendto',end,QL_INTERCEPT.ENTER)
    ### santizer
    
    ### patch
    #ql.patch(0x408a9b, b'\x00')
    
    ### debug
    #ql.os.set_api('vfork', fake_daemon)
    #ql.os.set_api('fork', fake_daemon)
    #ql.os.set_api('daemon',fake_daemon)
    
    ql.os.set_api('bd_read_sn',fake_bd_read_sn)
    #ql.debugger = "gdb:127.0.0.1:8888"
    ###
    ql.run()
