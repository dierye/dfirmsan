import random

trimbuf = ''

def log(text):
    with open("log.txt","a") as logf:
        logf.write(str(text)+'\n')

def init(seed):
    random.seed(seed)

def deinit():
    pass

def init_trim(buf):
    global trimbuf
    trimbuf = buf
    return 0

def trim():
    global trimbuf
    return trimbuf

def post_trim(success):
    return 0

def fuzz(buf, add_buf, max_size):
    buf = buf.replace(b'\r\r',b'\r')
    ret = buf.replace(b'AAAAAA', b'a'*0x1000)
    #ret = b''
    #lines = add_buf.split(b'\n')
    #for i in range(len(lines)):
    #    content = lines[i].split(b': ')
    #    if len(content) == 1:
    #        all_content = content[0] + b'\r\n'
    #    else:
    #        pre_content = content[0]
    #        content = content[1].split(b';')
    #        if :
    #            all_content = pre_content + content[0].rstrip(b'\n') + b'$(ls>/tmp/123)' + b'\r\n'
    #        else:
    #            for j in len(content):
    #                all_content = all_content + content[j].rstrip(b';') + b'$(ls>/tmp/123)' + b';'
    #            all_content = pre_content + all_content.rstrip(b'\n') + b'\r\n'
    #    ret = ret + all_content
    #    all_content = b''
    #log("fuzz")
    log(ret)
    #log(buf)
    #log(add_buf)
    return ret

#def havoc_mutation(buf, max_size):
#    mutated_buf = buf + b'a'*200 + b'\r\n'
#    log("mutated")
##    log(mutated_buf)
#    return mutated_buf

