#!/bin/sh

exec /usr/share/udhcpc/wlan1.$1
