<?
ftime("STRFTIME", "%Y/%m/%d,%T");
?>
