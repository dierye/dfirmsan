#!/bin/sh
gpiod &
