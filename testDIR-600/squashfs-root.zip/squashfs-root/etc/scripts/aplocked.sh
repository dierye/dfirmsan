#!/bin/sh
echo [$0] $1 $2 ... > /dev/console
WPS_PIN_ERROR_COUNT_NODE="/runtime/wps/setting/PinErrorCount"
WPS_APLOCKED_NODE="/runtime/wps/setting/aplocked"
PINErrCnt=`xmldbc -g $WPS_PIN_ERROR_COUNT_NODE`
if [ "$PINErrCnt" = "" ]; then
	exit 1
fi
case "$1" in
start)
	if [ $PINErrCnt -eq 1 ]; then
		xmldbc -k "WPS_APLOCKED"
		exec_cmd="/etc/scripts/aplocked.sh reset"
		xmldbc -t "WPS_APLOCKED:60:sh $exec_cmd > /dev/console"
	elif [ $PINErrCnt -ge 3 ]; then
		exec_cmd="/etc/scripts/aplocked.sh stop"
		xmldbc -s $WPS_PIN_ERROR_COUNT_NODE 0
		xmldbc -s $WPS_APLOCKED_NODE 1
		xmldbc -t "WPS_APLOCKED:60:sh $exec_cmd > /dev/console"	
		echo "<WPS>: AP enter into locked state!" > /dev/console
	fi	
	;;
stop)
	xmldbc -s $WPS_APLOCKED_NODE 0
	/etc/scripts/wps.sh setie
	/etc/scripts/wps.sh WPS_NONE
	echo "<WPS>: AP return to unlocked state!" > /dev/console
	;;
reset)
	APLOCKED=`xmldbc -g $WPS_APLOCKED_NODE`
	if [ "$APLOCKED" = "" ] || [ "$APLOCKED" = "0" ]; then
		xmldbc -s $WPS_PIN_ERROR_COUNT_NODE 0
		echo "<WPS>: AP reset pin error count to 0!" > /dev/console
	fi
	;;
*)
	echo "usage: $0 [start|stop|reset]" > /dev/console
	exit 9
	;;
esac
exit 0
