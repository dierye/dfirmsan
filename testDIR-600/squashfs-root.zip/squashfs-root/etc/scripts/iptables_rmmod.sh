#!/bin/sh
rmmod sw_tcpip
rmmod ifresetcnt
