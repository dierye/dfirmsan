#!/bin/sh
echo [$0] $1 ... > /dev/console
CFGSCRIPT="/etc/scripts/wifi/wps2cfg.php"
WPSUPSTATE="/etc/scripts/wifi/wpsupstate.php"
WPSPARSE_RESULT_CODE_NODE="/runtime/wps/parsing/result_code"
WPSPARSE_RESULT_REASON_NODE="/runtime/wps/parsing/result_reason"
WPSCONF="/var/run/wps.config"

case "$1" in
init)
	PIN=`wps -g`
	devdata set -e pin=$PIN
	;;
setie|pre_setie)
	xmldbc -P $CFGSCRIPT -V PHY_UID=WLAN-1 > $WPSCONF
	RET=`xmldbc -g $WPSPARSE_RESULT_CODE_NODE`
	if [ "$RET" != "0" ]; then
		REASON=`xmldbc -g $WPSPARSE_RESULT_REASON_NODE`
		echo $REASON > /dev/console
		exit 0
	fi
	if [ "$1" = "setie" ]; then
		wps -c $WPSCONF -e setup > /dev/console
	elif [ "$1" = "pre_setie" ]; then
		wps -c $WPSCONF -e pre_setup > /dev/console
	fi
	;;
eap:registrar|upnp:gdi)
	xmldbc -P $CFGSCRIPT -V PHY_UID=WLAN-1 -V PARAM=enrollee > $WPSCONF
	RET=`xmldbc -g $WPSPARSE_RESULT_CODE_NODE`
	if [ "$RET" != "0" ]; then
		REASON=`xmldbc -g $WPSPARSE_RESULT_REASON_NODE`
		echo $REASON > /dev/console
		exit 0
	fi
	wps -c $WPSCONF > /dev/console &
	;;
eap:enrollee|upnp:ssr)
	xmldbc -P $CFGSCRIPT -V PHY_UID=WLAN-1 > $WPSCONF
	RET=`xmldbc -g $WPSPARSE_RESULT_CODE_NODE`
	if [ "$RET" != "0" ]; then
		REASON=`xmldbc -g $WPSPARSE_RESULT_REASON_NODE`
		echo $REASON > /dev/console
		exit 0
	fi
	wps -c $WPSCONF > /dev/console &
	;;
pin)
	case "$2" in
	virtual)
		ConfigureMethod="virtual"
		;;
	physical)
		ConfigureMethod="physical"
		;;
	"")
		ConfigureMethod="virtual"
		;;
	esac
	xmldbc -P $CFGSCRIPT -V PHY_UID=WLAN-1 -V SELCONFIGUREMETHOD=$ConfigureMethod -V PBC=0 > $WPSCONF
	RET=`xmldbc -g $WPSPARSE_RESULT_CODE_NODE`
	if [ "$RET" != "0" ]; then
		REASON=`xmldbc -g $WPSPARSE_RESULT_REASON_NODE`
		echo $REASON > /dev/console
		exit 0
	fi
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_IN_PROGRESS > /dev/console &
	event WPS.INPROGRESS
	wps -c $WPSCONF -e int:pin > /dev/console &
	;;
pbc)
	case "$2" in
	virtual)
		ConfigureMethod="virtual"
		;;
	physical)
		ConfigureMethod="physical"
		;;
	"")
		ConfigureMethod="physical"
		;;
	esac
	xmldbc -P $CFGSCRIPT -V PHY_UID=WLAN-1 -V SELDEVCONFMETHOD=$ConfigureMethod -V PBC=1 > $WPSCONF
	RET=`xmldbc -g $WPSPARSE_RESULT_CODE_NODE`
	if [ "$RET" != "0" ]; then
		REASON=`xmldbc -g $WPSPARSE_RESULT_REASON_NODE`
		echo $REASON > /dev/console
		exit 0
	fi
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_IN_PROGRESS > /dev/console &
	event WPS.INPROGRESS
	wps -c $WPSCONF -e int:pbc > /dev/console &
	;;
restartap)
	shell="/var/run/wpsrestartap.sh"
	echo "#!/bin/sh"					>  $shell
	echo "xmldbc -P /etc/scripts/wifi/wpsset.php -V PHY_UID=WLAN-1" >> $shell
	echo "/etc/scripts/dbsave.sh"		>> $shell
	echo "service WIFI.WLAN-1 restart"	>> $shell
	echo "rm -f $shell"					>> $shell
	xmldbc -t "WPS:1:sh $shell > /dev/console"
	;;
WPS_NONE)
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_NONE > /dev/console &
	event WPS.NONE
	;;
WPS_IN_PROGRESS)
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_IN_PROGRESS > /dev/console &
	event WPS.INPROGRESS
	;;
WPS_ERROR)
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_ERROR > /dev/console &
	event WPS.ERROR
	;;
WPS_OVERLAP)
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_OVERLAP > /dev/console &
	event WPS.OVERLAP
	;;
WPS_SUCCESS)
	xmldbc -P $WPSUPSTATE -V PHY_UID=WLAN-1 -V STATE=WPS_SUCCESS > /dev/console &
	event WPS.SUCCESS
	;;
*)
	echo "usage: $0 [init|setie|pre_setie|eap:enrollee|eap:registrar|upnp:gdi|upnp:ssr|pin|pbc|" > /dev/console
	echo "           WPS_NONE|WPS_IN_PROGRESS|WPS_ERROR|WPS_OVERLAP|WPS_SUCCESS]" > /dev/console
	exit 9
	;;
esac
exit 0;
