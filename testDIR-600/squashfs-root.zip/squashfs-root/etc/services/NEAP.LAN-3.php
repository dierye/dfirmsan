<? /* Maker :sam_pan Date: 2010/3/22 03:35 */

include "/etc/services/NEAP/neapserver.php";
neapsetup("LAN-3");

?>