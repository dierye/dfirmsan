<?
include "/etc/services/WIFI/wifi.php";
fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");

/* Get the phyinf */
$phy1	= get_path_by_phy_uid(0, "WLAN-1");	if ($phy1 == "")	return;
$phyrp1	= get_path_by_phy_uid(1, "WLAN-1");	if ($phyrp1 == "")	return;
/* prepare needed config files */
$winf1	= query($phyrp1."/name");
$rtcfg	= "/var/run/RT2860.dat";
$hostapdcfg1		= "/var/servd/hostapd-".$winf1.".conf";
$hapd_eapuserfile1	= "/var/servd/hostapd-".$winf1.".wps.eap_user";
$upwifistatshlper	= "/etc/scripts/upwifistatshlper.sh";

/* config file of ralink driver. */
fwrite("a", $START, "xmldbc -P /etc/services/WIFI/rtcfg.php > ".$rtcfg."\n");

/* config file of hostapd. */
fwrite("a", $START,
	'xmldbc -P /etc/services/WIFI/hostapdcfg.php -V PHY_UID=WLAN-1 -V EAPUSERFILE='.$hapd_eapuserfile1.' > '.$hostapdcfg1.'\n'
	);

/************************* restart driver **************************/
/* reinstall wireless driver */
fwrite("a", $START,
//	'rmmod -f rt2860v2_ap\n'.
	'sleep 1\n'.
//	'insmod /lib/modules/rt2860v2_ap.ko\n'
	);
/* bringup the interface */
fwrite("a", $START,
	'ifconfig '.$winf1.' txqueuelen 100\n'.
	'ifconfig '.$winf1.' up\n');

	$idx = 0;
	foreach("/phyinf")
	{
		if(cut(query("uid"), 0, "-") == "WDS")
		{
			if(query("active")== 1 && query("media/peermac") != "")
			{
				$stsp = XNODE_getpathbytarget("/runtime", "phyinf", "uid", "WLAN-1", 0);
				$brinf      = query($stsp."/brinf");
				$brphyinf   = PHYINF_getphyinf($brinf);

				$addWDS = $addWDS."brctl addif ".$brphyinf." wds".$idx."\n";
				$delWDS = $delWDS."brctl delif ".$brphyinf." wds".$idx."\n";
				
				fwrite("a", $START,
					'ifconfig '.'wds'.$idx.' up\n'
					);
				fwrite("a", $STOP,
					'ifconfig '.'wds'.$idx.' down\n'
					);
				
				$idx++;	
			}
		}
	}

fwrite("a", $START,	
	'event WLAN-1.UP\n'.
	$addWDS
	);

fwrite("a", $START,
	'brctl setbwctrl br0 '.$winf1.' 900\n'.
	'echo 1 > /proc/net/br_forward_br0\n'
	);
fwrite("a", $STOP,
		$delWDS
		);
	if ($addWDS != "" && $delWDS != "")
	{
		fwrite("a", $START,
		'brctl stp '.$brphyinf.' on\n'
		);
		fwrite("a", $STOP,
		'brctl stp '.$brphyinf.' off\n'
		);
	}
/*******************************************************************/

/* start hostapd */
fwrite("a", $START, 'hostapd '.$hostapdcfg1.' &\n');

/* To invoke WPS service. We will always use the unique WPS name here,
   but it may be decided to contain different actions according to what
   we installed within Makefile.
 */
fwrite("a", $START,
		'service WPS start\n'
		);
fwrite("a", $STOP,
		'service WPS stop\n'
		);
		
/* start updatewifistats */
if (isfile($upwifistatshlper)==1) $upwifistatshlper=" -s ".$upwifistatshlper;
fwrite("a",$START,
	'updatewifistats -i '.$winf1.' -x '.$phy1.' -r '.$phyrp1.' -m RT2800'.$upwifistatshlper.' &\n'.
	'iwpriv ra0 set WlanLed=1\n'.
	'exit 0\n'
	);

/* stop updatewifistats & hostapd */
fwrite("a", $STOP,
	'killall updatewifistats\n'.
	'killall hostapd\n'
	);
/* remove interface from birdge */
fwrite("a", $STOP,
	'iwpriv ra0 set WlanLed=0\n'.
	'ifconfig '.$winf1.' down\n'.
	'rm -rf /var/run/RT2860.dat\n'.
	'exit 0\n'
	);
?>
