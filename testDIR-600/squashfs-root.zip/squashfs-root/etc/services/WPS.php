<?
include "/etc/services/WIFI/wifi.php";
fwrite("w",$START, "#!/bin/sh\n");
fwrite("w", $STOP, "#!/bin/sh\n");

/* Get the phyinf */
$phy1	= get_path_by_phy_uid(0, "WLAN-1");	if ($phy1 == "")	return;
$phyrp1	= get_path_by_phy_uid(1, "WLAN-1");	if ($phyrp1 == "")	return;
$wifi	= XNODE_getpathbytarget("/wifi", "entry", "uid", query($phy1."/wifi"), 0);
$en_wps = query($wifi."/wps/enable");

if ($en_wps == 1)
{
	fwrite("a", $START,
		'event WPSPBC.PUSH.PHYSICAL add "/etc/scripts/wps.sh pbc physical"\n'.
		'event WPSPBC.PUSH.VIRTUAL add "/etc/scripts/wps.sh pbc virtual"\n'.
		'event WPSPIN.PHYSICAL add "/etc/scripts/wps.sh pin physical"\n'.
		'event WPSPIN.VIRTUAL add "/etc/scripts/wps.sh pin virtual"\n'.
		'/etc/scripts/wps.sh setie\n'.
		'exit 0\n'
		);
	fwrite("a", $STOP,
		'event WPSPBC.NONE\n'.
		'event WPSPBC.PUSH.PHYSICAL add true\n'.
		'event WPSPBC.PUSH.VIRTUAL add true\n'.
		'event WPSPIN.PHYSICAL add true\n'.
		'event WPSPIN.VIRTUAL add true\n'
		);
}
/* stop wps*/
fwrite("a", $STOP,
	'killall wps\n'.
	'exit 0\n'
	);
?>
