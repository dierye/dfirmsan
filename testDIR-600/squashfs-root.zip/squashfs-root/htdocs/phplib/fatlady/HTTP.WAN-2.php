<?
include "/htdocs/phplib/fatlady/HTTP.WAN-1.php";
?>
