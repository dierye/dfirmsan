<?
set("/runtime/device/fcc", "0");
set("/runtime/device/ce","0");
?>
