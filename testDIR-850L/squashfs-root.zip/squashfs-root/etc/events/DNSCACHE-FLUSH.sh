#!/bin/sh
xmldbc -P /etc/events/DNSCACHE-FLUSH.php
exit 0;
