#!/bin/sh
echo [$0]: $1 ... > /dev/console
#if [ "$1" = "start" ]; then
#	/usr/sbin/UDPserver &
#else
#	killall UDPserver
#fi
