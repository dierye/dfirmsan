#!/bin/sh
echo [$0]: $1 ... > /dev/console
if [ -f "/var/run/LAN-1.UP" ]; then
	service IPTVSVR restart
else
	sleep 20
	service IPTVSVR restart
fi
