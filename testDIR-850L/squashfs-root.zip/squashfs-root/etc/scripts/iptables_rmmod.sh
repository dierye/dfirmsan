#!/bin/sh
rmmod sw_tcpip
