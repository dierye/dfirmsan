<?
include "/htdocs/phplib/trace.php";
include "/etc/services/IPTABLES/iptlan.php";
IPTLAN_build_command("LAN-1");
?>
