#!/bin/sh
UsbIppCheck
exit 1
