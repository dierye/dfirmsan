#!/bin/sh

trap "" 2

#The following will be populated by buildFS during the make process:
KERNELVER=4.1.52

case "$1" in
	start)
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_blog.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_TCPMSS.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_SKIPLOG.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nfnetlink.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nfnetlink_queue.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/ip_tables.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/iptable_filter.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_conntrack.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_nat.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_defrag_ipv4.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_conntrack_ipv4.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_nat_ipv4.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/iptable_nat.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_nat_masquerade_ipv4.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_nat.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/ipt_MASQUERADE.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_nat_redirect.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_REDIRECT.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_conntrack.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_state.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_limit.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_LOG.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_log_common.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_log_ipv4.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_mark.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/iptable_mangle.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_conntrack_proto_gre.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_nat_proto_gre.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_conntrack_pptp.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv4/netfilter/nf_nat_pptp.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/nf_conntrack_h323.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_dscp.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_DSCP.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_mac.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_mac_extend.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_flowlabel.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_u32.ko
		insmod /lib/modules/$KERNELVER/kernel/net/netfilter/xt_multiport.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv6/netfilter/ip6_tables.ko
		insmod /lib/modules/$KERNELVER/kernel/net/ipv6/netfilter/ip6table_mangle.ko
		
		echo 900 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_established
		echo 100000 > /proc/sys/net/netfilter/nf_conntrack_max
		echo 1 > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_close
		echo 20 >  /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_time_wait 
		echo e > /sys/class/net/eth0/queues/rx-0/rps_cpus
		echo "Loading TENDA_PRIVATE kernel modules"
		insmod /lib/modules/$KERNELVER/extra/kmbase.ko
		echo "add;Wire:eth0" > /proc/km/wan_interface
		insmod /lib/modules/$KERNELVER/extra/bm.ko
		insmod /lib/modules/$KERNELVER/extra/mac_group.ko
		insmod /lib/modules/$KERNELVER/extra/mac_filter.ko
		#insmod /lib/modules/$KERNELVER/extra/ip_filter.ko
		insmod /lib/modules/$KERNELVER/extra/ddos_ip_fence.ko
		insmod /lib/modules/$KERNELVER/extra/url_filter.ko
		insmod /lib/modules/$KERNELVER/extra/nos.ko
		#insmod /lib/modules/$KERNELVER/extra/interfaceisolate.ko
		insmod /lib/modules/$KERNELVER/extra/dnsredirect.ko
		insmod /lib/modules/$KERNELVER/extra/autodiscover.ko
		insmod /lib/modules/$KERNELVER/extra/os_identify.ko
		fc config --mcast 0
		exit 0
		;;

	stop)
		echo "removing GRE kernel modules not implemented yet..."
		exit 1
		;;

	*)
		echo "bcmbasedrivers: unrecognized option $1"
		exit 1
		;;

esac

