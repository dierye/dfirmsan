function addVideos() {
    addlink("eagle.mov", "The Eagle");
    addlink("CA.mov", "Captain America");
    addlink("CaA.mov", "Cowboys and Aliens");
    addlink("KFP2.mov", "Kung Fu Panda 2");
}