#!/bin/sh

exec /usr/share/udhcpc/eth0.$1
