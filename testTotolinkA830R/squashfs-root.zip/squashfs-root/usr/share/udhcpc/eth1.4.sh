#!/bin/sh

exec /usr/share/udhcpc/eth1.4.$1
