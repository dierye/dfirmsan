#!/bin/sh

exec /usr/share/udhcpc/usb0.$1
