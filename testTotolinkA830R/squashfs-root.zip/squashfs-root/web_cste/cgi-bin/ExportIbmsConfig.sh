#!/bin/sh
#output HTTP header
dateStr=`date  '+%Y%m%d'`
filename=\"ibms_config-$dateStr.tar.gz\"

echo "Pragma: no-cache"
echo "Cache-control: no-cache"
echo "Content-type: application/x-targz"
echo "Content-Transfer-Encoding: gzip, deflate"
echo "Content-Disposition: attachment; filename=$filename"
echo ""

cd /mnt
tar -cf /tmp/ibms_config.tar ibms_config
cd /tmp
gzip ibms_config.tar

cat /tmp/ibms_config.tar.gz 2>/dev/null
rm -rf /tmp/ibms_config.tar.gz