#!/bin/sh
#output HTTP header
eval `flash get HARDWARE_MODEL`
dateStr=`date  '+%Y%m%d'`
filename=\"syslog-$HARDWARE_MODEL-$dateStr.dat\"

echo "Pragma: no-cache"
echo "Cache-control: no-cache"
echo "Content-type: application/x-targz"
echo "Content-Transfer-Encoding: gzip, deflate"
echo "Content-Disposition: attachment; filename=$filename"
echo ""
cat /var/log/messages 2>/dev/null
