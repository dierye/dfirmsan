var loadMultiLangBt,loadLangFlag,loadLanguageType,loadLoginFlag,localStorageLanguage;
var languageSrc = "/js/language_en.js";

function loadLanguage(){
	var postVar = {"topicurl" : "setting/getLanguageCfg"};
	postVar = JSON.stringify(postVar);
	$.ajax({  
		type : "post", 
		url : "/cgi-bin/cstecgi.cgi", 
		data : postVar, 
		async : false, 
		success : function(Data){
			var jsonObject = JSON.parse(Data);
			loadMultiLangBt = jsonObject.multiLangBt;
			loadLangFlag = jsonObject.langFlag;
			loadLanguageType = jsonObject.languageType;
			loadLoginFlag = jsonObject.loginFlag;
		}
	});
}

loadLanguage();
$.ajaxSettings.async = false;	
var applang=(navigator.language||navigator.browserLanguage||navigator.userLanguage||navigator.systemLanguage).toLowerCase();
if (loadMultiLangBt.split(",").length>1&&loadLangFlag==0){
	if(applang=="ru"||applang.substr(0,2)=="ru"){
		localStorageLanguage="ru";
	}else if(applang=="pt"||applang.substr(0,2)=="pt"){
		localStorageLanguage="pt";
	}else if(applang=="vi"||applang.substr(0,2)=="vi"){
		localStorageLanguage="vn";
	}else if(applang=="ja"||applang.substr(0,2)=="ja"){
		localStorageLanguage="jp";
	}else if(applang=="zh-tw"||applang=="zh-hk"||applang=="zh-hant-tw"){
		localStorageLanguage="ct";
	}else if(applang=="zh-cn"||applang=="zh-hans-cn"){
		localStorageLanguage="cn";
	}else{
		localStorageLanguage="en";
	}
	if((applang=="ru"||applang.substr(0,2)=="ru")&&loadMultiLangBt.indexOf("ru")>-1){
		languageSrc = "/js/language_ru.js";
	}else if((applang=="pt"||applang.substr(0,2)=="pt")&&loadMultiLangBt.indexOf("pt")>-1){
		languageSrc = "/js/language_pt.js";
	}else if((applang=="vi"||applang.substr(0,2)=="vi")&&loadMultiLangBt.indexOf("vn")>-1){
		languageSrc = "/js/language_vn.js";
	}else if((applang=="ja"||applang.substr(0,2)=="ja")&&loadMultiLangBt.indexOf("jp")>-1){
		languageSrc = "/js/language_jp.js";
	}else if((applang=="zh-tw"||applang=="zh-hk"||applang=="zh-hant-tw")&&loadMultiLangBt.indexOf("ct")>-1){
		languageSrc = "/js/language_ct.js";		
	}else if((applang=="zh-cn"||applang=="zh-hans-cn")&&loadMultiLangBt.indexOf("cn")>-1){
		languageSrc = "/js/language_cn.js";
	}else{
		languageSrc = "/js/language_en.js";
	}
}else{
	localStorageLanguage=loadLanguageType;
	if(loadLanguageType=="ru"){
		languageSrc = "/js/language_ru.js";
	}else if(loadLanguageType=="pt"){
		languageSrc = "/js/language_pt.js";
	}else if(loadLanguageType=="vn"){
		languageSrc = "/js/language_vn.js";
	}else if(loadLanguageType=="jp"){
		languageSrc = "/js/language_jp.js";
	}else if(loadLanguageType=="ct"){
		languageSrc = "/js/language_ct.js";		
	}else if(loadLanguageType=="cn"){
		languageSrc = "/js/language_cn.js";
	}else{
		languageSrc = "/js/language_en.js";
	}
}
$.get(languageSrc, false, function(content) {
	eval(content);
});	
$.ajaxSettings.async = true;