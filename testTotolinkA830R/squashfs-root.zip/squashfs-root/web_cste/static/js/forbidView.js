var cur_id=0;
var cur_sub_id=0;
var unfold_1 = 0;
var icon_1 = 0;
function Node(id, pid, name, url, dualband, unfold, icon){
	this.id=id;
	this.pid=pid;
	this.name=name;
	this.url=url;
	this.dualband=dualband;
	this.unfold = unfold;
	this.icon =icon;
}

function Menu(objName){
	this.obj=objName;
	this.aNodes=[];
}

// Adds a new node to the node array
Menu.prototype.add=function(id, pid, name, url, dualband, unfold, icon){   
    this.aNodes[this.aNodes.length]=new Node(id, pid, name,url, dualband, unfold, icon);
}

Menu.prototype.toString=function(){
    var str='';
    var n=0;
    var id='';
    var pid='';
    var name='';
    var url=''; 
	var dualband='';
	var unfold='';
	var icon='';

	for (n; n<this.aNodes.length; n++){
        id=this.aNodes[n].id;
        pid=this.aNodes[n].pid;
        name=this.aNodes[n].name;
        url=this.aNodes[n].url;
		dualband=this.aNodes[n].dualband;
        unfold = this.aNodes[n].unfold;
		icon = this.aNodes[n].icon;
		
        if(pid==0)
        {
            str += "<A href=";
            str += url;
            str += " target = view";
			str += "><div id =";
            str += id;
			if(unfold == 0)
				str += "  class=menu onmouseover=My_T_Over(";
			else
				str += "  class=menu1 onmouseover=My_T_Over(";
            str += id;
			str += ",";
			str += unfold;
			str += ",";
			str += icon;
            str += ")";
            str += " onmouseout=My_T_Out(";
            str += id;
			str += ",";
			str += unfold;
			str += ",";
			str += icon;
            str += ")";
            str += " onclick=My_Open_T(";
            str += id;
			str += ",";
			str += unfold;
			str += ",";
			str += icon;
            str += ")>";
			str += "<ul style='clear:both;'><li style='float:left;height:34px;'>";
			str += "<img id=";
			str += "img"+id;
			str += " src=\"/static/images/"+icon+".png\" border=\"0\">";
			str += "</li>";
			str += "<li>";	
            str += name;
			str += "</li></ul>";
            str += "</div></A><ul id=submenu_";
            str += id;
            str += " class=dis >";
            str += "</ul>";
        }
        else
        {
            str = str.substring(0, str.length-5);
            str += "<li style='clear:left;' id=";
            str += id;
            str += "  class=menu_link";
            str += ">";
            str += "<img src='/static/images/submenu.gif' algin='absmiddle'>&nbsp;&nbsp;<A href=";
            str += url;
            aid=id+"01";
            str += " id=";
            str += aid;
			str += " onclick='return My_Open_A(";
            str += id;
            str += ",";
            str += aid;	
			str += ")'";
			str += " hidefocus";
            str += " target=view> ";
            str += name;
            str += "</A>";
            str += "</li>";
            str += "</ul>";     
        }
    }
    return str;
}

function My_T_Over(id,unfold,icon)
{
    var x=document.getElementById(id);
	if(unfold==0)
	{
		document.getElementById("img"+id).src="/static/images/"+icon+".png";
		x.className="menu_over3";
	}
	else
	{
		if(cur_sub_id && (cur_id == id))
			x.className="menu_over2";
		else
			x.className="menu_over1";
	}
}

function My_T_Out(id,unfold,icon)
{
    var x=document.getElementById(id);
    if(cur_id==id)
    {
		if(unfold == 0)
		{	
			document.getElementById("img"+id).src="/static/images/"+icon+"_ON.png";
			x.className= "menu_out3";
		}
		else
		{
			if (0==cur_sub_id && unfold == 1)
				x.className= "menu1";
			else
				x.className= "menu_out2";
		}
    }
    else
    {
		if(unfold == 0)
			x.className= "menu";
		else
			x.className= "menu1";
    }
}

function setWlanIdx(val){
	var postVar={topicurl:"setting/setWebWlanIdx"};
	postVar['webWlanIdx']="'"+val+"'";
    postVar=JSON.stringify(postVar);
	$.ajax({  
       	type : "post", url : " /cgi-bin/cstecgi.cgi", data : postVar, async : true,  success : function(Data){
			//top.frames['view'].location.reload();
		}
   	});	
}

function My_Open_T(id,unfold,icon){  
    var subnode;
    if(cur_id != id){
   		if (dualband==1){
			if(4==id){//2.4g
				top.frames[0].wifiSelect=1;
				setWlanIdx(1);
			}else if(10==id){//5g
				top.frames[0].wifiSelect=0;
				setWlanIdx(0);
			}
   		}else{
			if(4==id){//2.4g
				top.frames[0].wifiSelect=0;
				setWlanIdx(0);
			}
		}
		
        if(cur_id != 0)
        {			
			if (cur_sub_id != 0)
            {
				try{subnode=document.getElementById(cur_sub_id + "01");
					subnode.style.color = "";
					subnode.style.fontWeight = "";
				}catch(e){};
            }
			
          	try{document.getElementById("submenu_"+cur_id).className="dis";}catch(e){};
		  	
			if(unfold_1 == 0)
			{
				try{document.getElementById(cur_id).className="menu";}catch(e){};
		  	}
			else
			{
				try{document.getElementById(cur_id).className="menu1";}catch(e){};
			}
        }
        
        try{document.getElementById("submenu_"+id).className="block";}catch(e){};
		
		if(unfold == 0)
		{   
			if(cur_id != 0)
			{
				try{document.getElementById("img"+cur_id).src="/static/images/"+icon_1+".png";}catch(e){};
			}
			try{document.getElementById("img"+id).src="/static/images/"+icon+"_ON.png";}catch(e){};
			try{document.getElementById(id).className ="menu_out3";}catch(e){};
		}
		else 
		{
			if(cur_id != 0)
			{
				try{document.getElementById("img"+cur_id).src="/static/images/"+icon_1+".png";}catch(e){};
			}
			try{document.getElementById("img"+id).src="/static/images/"+icon+"_ON.png";}catch(e){};
			try{document.getElementById(id).className ="menu_over2";}catch(e){};
		}
		
        cur_id =id;
        cur_sub_id =cur_id+"01";
		unfold_1 =unfold;
		icon_1 =icon;
        try{subnode=document.getElementById(cur_sub_id + "01");
			if (subnode != null)
			{
				subnode.style.color = "#0095c5";
				subnode.style.fontWeight = "700";
			}
			else
			{
				cur_sub_id=0;
			}
		}catch(e){};
    }
	else
	{
		var x=document.getElementById(id);
		if(unfold == 0)
		{
			if(x.className = "menu")
				x.className = "menu_out3";
			try{document.getElementById("img"+id).src="/static/images/"+icon+"_ON.png";}catch(e){};
		}
		else
		{
			if(cur_id != 0)
			{
				if(cur_id==id && 0==cur_sub_id)
				{
					try{document.getElementById("submenu_"+id).className="block";}catch(e){};
					
					if(unfold == 0)
					{
						;
					}
					else
					{
						try{document.getElementById(id).className ="menu_over2";}catch(e){};
						try{document.getElementById("img"+id).src="/static/images/"+icon+"_ON.png";}catch(e){};
					}
					
					cur_id =id;
					cur_sub_id =cur_id+"01";
					unfold_1 =unfold;
					icon_1 =icon;
					try{subnode=document.getElementById(cur_sub_id + "01");
						if (subnode != null)
						{
							subnode.style.color = "#0095c5";
							subnode.style.fontWeight = "700";
						}
						else
						{
							cur_sub_id=0;
						}
					}catch(e){};
				}
				else
				{
					if (cur_sub_id != 0)
					{
						try{subnode=document.getElementById(cur_sub_id + "01");
						subnode.style.color = "";
						subnode.style.fontWeight = "";}catch(e){};
						
						if(cur_id != 0)
						{
							try{document.getElementById("img"+cur_id).src="/static/images/"+icon_1+".png";}catch(e){};
						}
						
					}
					
					try{document.getElementById("submenu_"+cur_id).className="dis";}catch(e){};
					try{document.getElementById(cur_id).className="menu1";}catch(e){};
					cur_sub_id=0;
				}
			}
		}
	}
	var x=document.getElementById(id);
	x.parentNode.href=addTimestamp(x.parentNode.href);
}

function addTimestamp(url){
	var _url=url;
	if(_url.indexOf('?')==-1){
		_url += '?timestamp=' + (new Date()).getTime();
	}else{
		if(_url.indexOf('timestamp')==-1)
			_url += "&timestamp=" + (new Date()).getTime();
		else
			_url=_url.replace(/timestamp=.*/ig,"timestamp=" + (new Date()).getTime());
	}
	return _url;
}

function My_Open_A(id,aid){  
    var x=document.getElementById(aid);
	if('999' == id){
		if(confirm(JS_logout)){
			clearCookie(document.cookie.split("=")[0]);
			//top.location.href='/login.asp';
			parent.location.href='/formLogoutAll.htm';
		}
		return false;
	}
    if(cur_sub_id!=0){
        var old=document.getElementById(cur_sub_id + "01");
        old.style.color="";
        old.style.fontWeight="";
		old.style.textDecoration="none";
    }
	if(id=='90301') counts=0;
    x.style.color="#0095c5";
    x.style.fontWeight="700";
	x.style.textDecoration="underline";
	x.href=addTimestamp(x.href);
    cur_sub_id=id;
}

///////////////////////////////////////
function addEventHandler(target, type, func){
	if (target.addEventListener) 
		target.addEventListener(type, func, false);
	else if (target.attachEvent) 
		target.attachEvent("on" + type, func);
	else 
		target["on" + type]=func;
}

var stopEvent=function(e){
    e=e || window.event;
    if(e.preventDefault){
      	e.preventDefault();
      	e.stopPropagation();
    }else{
      	e.returnValue=false;
      	e.cancelBubble=true;
    }
}
  
function clearCookie(name){    
 	setCookie(name, "", -1);    
}    
   
function setCookie(name, value, seconds){    
	seconds=seconds || 0;      
	var expires="";    
	if (seconds != 0 ){   
		var date=new Date();    
		date.setTime(date.getTime()+(seconds*1000));    
		expires="; expires="+date.toGMTString();    
	}    
 	document.cookie=name+"="+escape(value)+expires+"; path=/";  
} 